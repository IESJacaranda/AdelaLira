package Repaso;

import java.util.Scanner;

public class mainCafetera {

	static Scanner teclado = new Scanner (System.in);
	
	public static final String MENU = "Servir caf� solo (1 euro)\r\n"
			+ "2. Servir leche (0,8 euros)\r\n"
			+ "3. Servir caf� con leche (1,5 euros)\r\n"
			+ "4. Consultar estado m�quina. Aparecen los datos de los dep�sitos y del\r\n"
			+ "monedero\r\n"
			+ "5. Apagar m�quina y salir";
	
	public static void main(String[] args) {
		Cafetera cafetera = new Cafetera();
		
		int menu=0;
		double cantidad=0.0;
		
		while (menu<5) {
			mostrarMenu();
			menu=Integer.parseInt(teclado.nextLine());
			
			switch(menu) {
			case 1:
				System.out.println("Introduzca el importe");
				cantidad = Double.parseDouble(teclado.nextLine());
				cafetera.sirveCafe(cantidad);
				break;
			case 2:
				System.out.println("Introduzca el importe");
				cantidad = Double.parseDouble(teclado.nextLine());
				cafetera.sirveLeche(cantidad);
				break;
			case 3:
				System.out.println("Introduzca el importe");
				cantidad = Double.parseDouble(teclado.nextLine());
				cafetera.sirveCafeConLeche(cantidad);
				break;
			case 4:
				System.out.println(cafetera.toString());
				break;
			case 5:
				System.out.println("Saliendo");
				break;
			default:
				System.out.println("Ha habido un problema");
				break;
			}
			
		}
		

	}
	
	public static void mostrarMenu() {
		System.out.println(MENU);
	}

}
