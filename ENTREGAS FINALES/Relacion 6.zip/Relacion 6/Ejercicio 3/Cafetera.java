package Repaso;

public class Cafetera {
	
	public final static double PRECIO_CAFE=1.0;
	public final static double PRECIO_LECHE=0.8;
	public final static double PRECIO_CAFECONLECHE=1.5;
	
	private int depositoCafe;
	private int depositoLeche;
	private int depositoVasos;
	private double monedero;

	public Cafetera() {
		this.monedero=50;
		this.depositoCafe=50;
		this.depositoLeche=50;
		this.depositoVasos=80;
		this.monedero=50;
	}
	
	
	public Cafetera(int cafe, int leche, int vasos) {
		this.depositoCafe=cafe;
		this.depositoLeche=leche;
		this.depositoVasos=vasos;
		this.monedero=monedero;
	}

	public double cambio (double dinero, double precio) {
		if(dinero>=precio) {
			return dinero-precio;
		}
		else {
			System.out.println("No hay suficiente dinero");
		}
	}
	
	
	public void sirveCafe(double dinero) {
		double cambio =cambio(dinero, PRECIO_CAFE);
		if (cambio!=1) {
			this.depositoCafe--;
			this.depositoVasos--;
			this.monedero=this.monedero+dinero-cambio;			
		}
		else {
			System.out.println("No se ha podido comprar el articulo");
		}
	}
	
	
	public void sirveLeche(double dinero) {
		double cambio =cambio(dinero, PRECIO_LECHE);
		if (cambio!=1) {
			this.depositoLeche--;
			this.depositoVasos--;
			this.monedero=this.monedero+dinero-cambio;			
		}
		else {
			System.out.println("No se ha podido comprar el articulo");
		}
	}

	public void sirveCafeConLeche(double dinero) {
		double cambio =cambio(dinero, PRECIO_CAFECONLECHE);
		if (cambio!=1) {
			this.depositoCafe--;
			this.depositoLeche--;
			this.depositoVasos--;
			this.monedero=this.monedero+dinero-cambio;			
		}
		else {
			System.out.println("No se ha podido comprar el articulo");
		}
	}

	

	@Override
	public String toString() {
		return "Cafetera [depositoCafe=" + depositoCafe + ", depositoLeche=" + depositoLeche + ", depositoVasos="
				+ depositoVasos + ", monedero=" + monedero + "]";
	}


	public int getDepositoCafe() {
		return depositoCafe;
	}


	public void setDepositoCafe(int depositoCafe) {
		this.depositoCafe = depositoCafe;
	}


	public int getDepositoLeche() {
		return depositoLeche;
	}


	public void setDepositoLeche(int depositoLeche) {
		this.depositoLeche = depositoLeche;
	}


	public int getDepositoVasos() {
		return depositoVasos;
	}


	public void setDepositoVasos(int depositoVasos) {
		this.depositoVasos = depositoVasos;
	}


	public double getMonedero() {
		return monedero;
	}


	public void setMonedero(double monedero) {
		this.monedero = monedero;
	}
	
	
	
	
	
	
}