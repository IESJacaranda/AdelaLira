package Ejercicio1;

import java.util.Scanner;

import ejercicio1.Linea;
import ejercicio1.Punto;

public class Main {
	
	public final static String MENU="1. Mover l�nea: Solicitar� el movimiento (A-arriba, B-ABajo, I-Izquierda, DDerecha) y realice el movimiento \n 2. Mostrar linea. \n 3. Salir.";
	public final static String MENU_MOVIMIENTO="1. A-arriba. \n 2. B-abajo. \n 3. I-Izquierda. \n 4. D-Derecha";


	static Scanner teclado = new Scanner (System.in);
	
	public static void main(String[] args) {
	
		Linea linea = new Linea ();
		Punto punto = new Punto();
		
		int opcion = 0;
		int opcion2=0;
		
		while(opcion<3) {
			mostrarMenu();
			opcion = Integer.parseInt(teclado.nextLine());
			
			switch(opcion) {
			case 1:
				mostrarMenuMovimiento();
				opcion2=Integer.parseInt(teclado.nextLine());
				if(opcion2=='A') {
					System.out.println("�Qu� movimiento desea realizar?");
					double movimiento = Double.parseDouble(teclado.nextLine());
					punto.moverArriba(movimiento);
				}
				if (opcion2=='B') {
					System.out.println("�Qu� movimiento desea realizar?");
					double movimiento = Double.parseDouble(teclado.nextLine());
					punto.moverAbajo(movimiento);
				}
				if (opcion2=='I') {
					System.out.println("�Qu� movimiento desea realizar?");
					double movimiento = Double.parseDouble(teclado.nextLine());
					punto.moverIzquierda(movimiento);
				}
				if (opcion2=='D') {
					System.out.println("�Qu� movimiento desea realizar?");
					double movimiento = Double.parseDouble(teclado.nextLine());
					punto.moverDerecha(movimiento);
				}
				else {
					System.out.println("Error");
				}
				break;
			case 2:
				System.out.println(linea.getPuntoA());
				System.out.println(linea.getPuntoB());
				break;
			default:
				System.out.println("Saliendo");
				break;
			}
			
		}
		
		

	}
	
	public static void mostrarMenu () {
		System.out.println(MENU);
	}
	
	public static void mostrarMenuMovimiento () {
		System.out.println(MENU_MOVIMIENTO);
	}
	
}

