package ejercicio3;

import java.util.*;

public class Principal {
	

	
	public final static String MENU= "1. Llenar jarra: Se solicitar� con la pregunta ��Qu� jarra desea llenar (A/B)?� y\r\n"
			+ "se llenar� la jarra correspondiente.\r\n"
			+ "2. Vaciar jarra: Se realizar� la pregunta ��Qu� jarra desea vaciar (A/ B)?� y se\r\n"
			+ "vaciar� la jarra correspondiente.\r\n"
			+ "3. Volcar jarra A en B .\r\n"
			+ "4. Volcar jarra B en A.\r\n"
			+ "5. Ver estado de las jarras: Se mostrar� la capacidad y el agua que contiene, tanto\r\n"
			+ "para la jarra A como para la B.\r\n"
			+ "6. Salir: Cuando salga debe mostrarse un mensaje que indique \"El total de agua\r\n"
			+ "que se ha gastado llenando jarras es XXX litros\".";
	public final static String JARRA= "�Qu� jarra desea llenar (A/B)?";
	public final static String JARRAVACIAR= "�Qu� jarra desea vaciar (A/B)?";
	
	static Scanner teclado=new Scanner (System.in);

	public static void main(String[] args) {

		Jarra jarraA =new Jarra();
		Jarra jarraB =new Jarra();
		
		int opcion=0;
		
		
		while(opcion<6) {
			mostrarMenu();
			opcion=Integer.parseInt(teclado.nextLine());
			
			switch(opcion) {
			case 1:
				System.out.println("�Que jarra desea seleccionar A(1) o B(2)");
				opcion=teclado.nextInt();
				while (opcion!=1 && opcion!=2) {
					System.out.println("La opcion no es valida");
				}
				if (opcion==1) {
					jarraA.llenarJarra();
				}
				else {
					jarraB.llenarJarra();
				}
				break;
			case 2:
				System.out.println("�Que jarra desea seleccionar A(1) o B(2)");
				opcion=teclado.nextInt();
				while (opcion!=1 && opcion!=2) {
					System.out.println("La opcion no es valida");
				}
				if (opcion==1) {
					jarraA.vaciarJarra();
				}
				else {
					jarraB.vaciarJarra();
				}
				break;
			case 3:
				jarraA.volcarAenB(jarraB);
				break;
			case 4:
				jarraB.volcarAenB(jarraA);
				break;
			case 5:
				System.out.println(jarraA.estadoJarra(jarraB));
			case 6:
				System.out.println("Saliendo, el total de agua que se ha gastado llenando jarras es XXX litros");
				break;
			}			
		}
		
	
	}
	
	public static void mostrarMenu() {
		System.out.println(MENU);
	}

}
