package ejercicio3;

public class Jarra {

	private double capacidad;
	private double totalAgua;
	private double cantidad;
		
	
	public Jarra () {
		
	}
	
	public Jarra (double capacidad) {
		this.capacidad=capacidad;
	}

	public double setCapacidad() {
		return capacidad;
	}
	
	public void setCapacidad (double capacidad) {
		this.capacidad=capacidad;
		this.totalAgua=0;
	}

	public double getTotalAgua() {
		return totalAgua;
	}

	public void setTotalAgua(double totalAgua) {
		this.totalAgua = totalAgua;
	}

	public double getCantidad() {
		return cantidad;
	}

	public void setCantidad(double cantidad) {
		this.cantidad = cantidad;
	}
	
	public void llenarJarra() {
		if(this.cantidad<this.cantidad) {
			this.totalAgua+=this.capacidad-this.cantidad;
			this.cantidad=this.capacidad;
			System.out.println("La jarra esta llena");
		}
		
		else {
			System.out.println("La jarra ya esta llena");
		}
	}
	
	public void vaciarJarra() {
		if (this.cantidad>0) {
			this.cantidad=0;
			System.out.println("La jarra ha sido vaciado correctamente");
		}
		
		else {
			System.out.println("La jarra ya estaba vacia");
		}
	}
	
	public void volcarAenB(Jarra j2) {
		if (j2.cantidad==j2.capacidad) {
			System.out.println("No se puede realizar la operaci�n, la jarra que has seleccionado ya esta llena");
		}
		
		else if (this.cantidad==0) {
			double posibilidadAgua=j2.capacidad-j2.cantidad;
			if (posibilidadAgua<=this.cantidad) {
				j2.cantidad+=posibilidadAgua;
				this.cantidad-=posibilidadAgua;
				System.out.println("La jarra ha sido llenada correctamente");
			}
			
			else if (posibilidadAgua>this.cantidad) {
				j2.cantidad+=this.cantidad;
				this.totalAgua+=this.cantidad;
				this.cantidad=0;
				System.out.println("Jarra llenada correctamente");
			}
		}
		
		
		
	}

	public String estadoJarra (Jarra j2) {
		return "Jarra A: [capacidad=" + this.capacidad + ", cantidad=" + this.cantidad + "Jarra B: [capacidad=" + j2.capacidad + ", cantidad=" +j2.cantidad +"]";
	}
	
	public String calaculaAguaTotal(Jarra j2) {
		return "El total del agua moida ha sido de " + (this.totalAgua + j2.totalAgua)  + " L";
	}
	
	
	
	
}