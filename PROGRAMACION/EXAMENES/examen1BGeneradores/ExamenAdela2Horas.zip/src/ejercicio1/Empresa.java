package ejercicio1;

import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.util.HashSet;

public class Empresa {
	
	private String nombre;
	private HashSet<GeneradorEolico> listaEolicos;
	private HashSet<GeneradorSolar> listaSolares;
	
	public Empresa (String nombre) {
		this.nombre=nombre;
		this.listaEolicos=new HashSet<GeneradorEolico>();
		this.listaSolares=new HashSet<GeneradorSolar>();
	}

	public void addGeneradorEolico(GeneradorEolico generador) {
		listaEolicos.add(generador);
		
	}
	
	public void addGeneradorSolar(GeneradorSolar generador){
		listaSolares.add(generador);
	}
	
	public void mostrarGeneradorPorFecha() {
		
	}
	
	public void mostrarGeneradorPorLocalidad() {
		
	}	
	
	public void mostrarGeneradoresEmpresa() {
		StringBuilder sb = new StringBuilder();
		
		for(GeneradorEolico i : listaEolicos) {
			sb.append(i+"\n");
		}
		System.out.println(sb.toString());
	}
	
	public void borrarGenerador(int codigo) {
		if(listaEolicos.contains(GeneradorEolico.codigo)) {
			listaEolicos.remove(GeneradorEolico.codigo);
		}
	}
	
	public void energiaEmpresa() {

	}
	
	public void existeGeneradorLocalidad(String localidad) {
		
	}
	
	
	public void listarGeneradoresSolares() {
		StringBuilder sb = new StringBuilder();
		
		for(GeneradorSolar i : listaSolares) {
			sb.append(i+"\n");
		}
		System.out.println(sb.toString());
	}

	public void listarInstalacionesEnFecha(LocalDate fecha) {
		System.out.println("Reserva en la fecha " + fecha);
		for(GeneradorEolico i: listaEolicos) {
			if(i.getFecha().isAfter(fecha)) {
				System.out.println(i.toString()); //EL toString DE RESERVA
			}
		}
	}
	
}
