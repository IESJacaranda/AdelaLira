package ejercicio1;

public interface Dinero {

	public double dinero();
	
}
