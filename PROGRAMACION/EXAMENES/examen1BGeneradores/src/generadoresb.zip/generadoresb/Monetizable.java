package generadoresb;

public interface Monetizable {

	double precio(double precioEnergia);
	
}
