package generadoresb;

public enum TipoGenerador {

	FOTOVOLTAICO,
	TERMICO,
	HIBRIDO;
	
	private String tipo;

	public String getTipo() {
		return tipo;
	}	
}
